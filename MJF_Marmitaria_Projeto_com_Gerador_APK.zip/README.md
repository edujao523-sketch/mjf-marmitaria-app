# MJF Marmitaria — projeto inicial Android

## O que está incluído
- Identidade visual preto e dourado.
- Cardápio diário editável (nome, descrição, foto e preços M/G).
- Carrinho, quantidade e cálculo de total.
- Entrega ou retirada.
- Taxa de entrega configurável.
- Checkout com Pix combinado, dinheiro ou cartão na entrega/retirada.
- Encaminhamento do pedido ao WhatsApp configurado no painel.
- Tela de pedidos e atualização manual de status.
- Manifest e service worker para suporte PWA.

## Importante: estado atual
Este pacote é um **protótipo funcional local**, ainda não um APK pronto para distribuição.
Os dados ficam no armazenamento do aparelho. Para o cardápio e pedidos sincronizarem entre o celular administrativo e os celulares dos clientes, é necessário configurar um backend online (por exemplo, Supabase ou Firebase), regras de segurança e autenticação administrativa. O WhatsApp da marmitaria, endereço de retirada, taxa de entrega e credenciais ainda precisam ser configurados.

## Testar no navegador
Abra `www/index.html` em um servidor local ou hospede a pasta `www` em HTTPS. O navegador pode restringir algumas funções se o arquivo for aberto diretamente.

## Gerar projeto Android com Capacitor
Requisitos: Node.js LTS, Android Studio e Android SDK.
1. `npm install`
2. `npx cap add android`
3. `npx cap sync android`
4. `npx cap open android`
5. No Android Studio, aguarde o Gradle sincronizar.
6. Use Build > Build Bundle(s) / APK(s) > Build APK(s).

Para distribuir o APK, teste em aparelhos reais e assine a versão de release. Não compartilhe uma versão debug como versão final.

## Configurações pendentes
- Número WhatsApp com DDI 55 + DDD + número.
- Endereço e instruções de retirada.
- Taxa de entrega.
- Chave Pix / QR Code quando disponível.
- Backend compartilhado e autenticação antes de produção.


## Gerar um APK usando somente o celular (compilação na nuvem)

Este pacote inclui um fluxo do GitHub Actions para compilar um APK de teste na nuvem, sem instalar Android Studio no celular.

1. No navegador do celular, entre em https://github.com e crie uma conta ou faça login.
2. Crie um repositório novo (por exemplo, `mjf-marmitaria-app`).
3. Envie os arquivos deste projeto para o repositório, mantendo as pastas `www` e `.github/workflows`.
4. Abra a aba **Actions** do repositório e habilite os workflows, se o GitHub pedir.
5. Selecione **Gerar APK MJF Marmitaria** e toque em **Run workflow**.
6. Quando terminar com sucesso, abra a execução e baixe o artefato **MJF-Marmitaria-APK-debug**. Dentro dele estará `app-debug.apk`.

Observações:
- O APK gerado por esse fluxo é uma versão **debug para teste**, não uma versão assinada de produção.
- O aplicativo atual ainda guarda cardápio e pedidos localmente em cada aparelho. Para todos os clientes verem o mesmo cardápio atualizado e a marmitaria receber pedidos num painel compartilhado, ainda é necessário integrar um banco de dados/backend online e proteger o acesso administrativo.
- Não publique credenciais, senhas ou chaves privadas no repositório.
